package org.javaro.lecture;

public class Member {
	private String name;
	private String memNumber;
	public Member(String memNumber) { this.memNumber = memNumber;}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMemNumber() {
		return this.memNumber;
	}
	public void setmemNumber(String memNumber) {
		this.memNumber = memNumber;
	}
	public String toString() {
		return "전화번호="+this.getMemNumber()+",대여자="+this.getName();
	}
}
