package org.javaro.lecture;

public class Tool {

	private String toolname; 

	private Member member;
	public Tool(String toolname) {	this.toolname= toolname; }
	public void setToolname(String toolname) { this.toolname=toolname; }
	public String getToolname() { return this.toolname; }
	
	public void setMember(Member member) { this.member=member; }
	public Member getMember() { return this.member; }
     
	public String toString() {
		String available;
				if (this.getMember() == null) {
					available = "대여가능";
				} else {
					available = "대여인="+this.getMember().getName();
				}
				return "공구:"+this.getToolname()+" "+available;
				}
			}

	