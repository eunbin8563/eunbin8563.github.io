package org.javaro.lecture;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.javaro.lecture.Tool; import org.javaro.lecture.Member;
public class HardwareStore {
			public String storeName; public ArrayList<Tool>tools; public ArrayList<Member> members;
			public HardwareStore(String storeName) {
				this.storeName=storeName;	tools=new ArrayList<Tool>();	members=new ArrayList<Member>();
			}
			public String getStoreName() {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
				return this.storeName; }
			public ArrayList<Tool> getTools(){
				return this.tools; }
			public ArrayList<Member> getMembers(){
				return this.members; }
			public void addTool(Tool tool) {
				this.tools.add(tool); }
			public void removeTool(Tool tool) {
				this.tools.remove(tool); 
		}
		public void addMember(Member member) {
			this.members.add(member);
		}
		public void removeMember(Member member) {
			this.members.remove(member);
		}
		public boolean checkOut(Tool tool, Member member) {
			if (tool.getMember() == null)
			{
				tool.setMember(member);
				return true;
			} else {
				return false;
			}
		}
		public boolean checkIn(Tool tool) {
			if (tool.getMember()!=null) {
				tool.setMember(null);
				return true;
			} else {
				return false;
			}
		}
		public ArrayList<Tool> getToolsForMember(Member member) {
			ArrayList<Tool>result = new ArrayList<Tool>();
			for (Tool aTool : this.getTools()) {
				if((aTool.getMember()!=null)&&(aTool.getMember().getMemNumber().equals(member.getMemNumber()))) {
					result.add(aTool);
				}
			}
			return result;
		}
		public ArrayList<Tool> getAvailableTools(){
			ArrayList<Tool> result= new ArrayList<Tool>();
			for (Tool aTool : this.getTools()) {
				if (aTool.getMember() == null) {
					result.add(aTool);
				}
			}
			return result;
		}
		public ArrayList<Tool> getUnavailableTools(){
			ArrayList<Tool> result= new ArrayList<Tool>();
			for (Tool aTool : this.getTools()) {
				if (aTool.getMember() != null) {
					result.add(aTool);
				}
			}
			return result;
		}
		
		public String toString() {
			Calendar cal = Calendar.getInstance();
		    cal.setTime(new Date());
		    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		    cal.add(Calendar.DATE, 2);
			return this.getStoreName()+"의 보유 공구="+this.getTools().size()+"개, 회원수="+this.getMembers().size()+"명, "+"반납일"+df.format(cal.getTime());
		}
		public void printStatus() {
			System.out.println("--- 공구 현황 ---\n"+this.toString());
			for(Tool aTool : this.getTools()) {
				System.out.println(aTool);
			}
			for(Member member : this.getMembers()) {
				int count = this.getToolsForMember(member).size();
				System.out.println(member + "은/는"+count+"개 대여중");
			}
			System.out.println("현재 대여 가능 공구: "+ this.getAvailableTools().size());
			System.out.println("---리포트 종료---"); 
			
		}
		}

