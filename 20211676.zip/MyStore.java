package org.javaro.lecture;
import org.javaro.lecture.Tool;import org.javaro.lecture.HardwareStore; import org.javaro.lecture.Member;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class MyStore {
	public static void main(String[] args) {
	
	HardwareStore myStore = new HardwareStore("공구점");
	Tool tool1 = new Tool("망치"); 
	Tool tool2 = new Tool("드릴");
	Tool tool3 = new Tool("톱");
	Tool tool4 = new Tool("사다리");
	Tool tool5 = new Tool("삽");
	Member mem1 = new Member("01012345678"); 
	Member mem2 = new Member("01087654321");
	Member mem3 = new Member("01011112222");
	Member mem4 = new Member("01033334444");
	Calendar cal = Calendar.getInstance();
    cal.setTime(new Date());
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	mem1.setName("이몽룡");	mem2.setName("변학도");	mem3.setName("성춘향");	mem4.setName("홍길동");
	myStore.addTool(tool1);	myStore.addTool(tool2); myStore.addTool(tool3); myStore.addTool(tool4); myStore.addTool(tool5);
	myStore.addMember(mem1);	myStore.addMember(mem2);	myStore.addMember(mem3);	myStore.addMember(mem4);
	
	System.out.println("공구 관리 시스템 생성");
	myStore.printStatus();
	System.out.println("망치를 변학도에게 대여");
	myStore.checkOut(tool1,mem2);
	myStore.printStatus();
	System.out.println("망치를 반납,"+"반납날짜 "+ df.format(cal.getTime()));
	myStore.checkIn(tool1);
	System.out.println("드릴을 이몽룡에게 대여");
	myStore.checkOut(tool2, mem1);
	myStore.printStatus();
	System.out.println("사다리를 성춘향에게 대여");
	myStore.checkOut(tool4,mem3);
	myStore.printStatus();
	System.out.println("사다리를 반납,"+"반납날짜 "+ df.format(cal.getTime()));
	myStore.checkIn(tool4);
	myStore.printStatus();
	}
	}
